# Launcher Zero Two

Redmi 14C / HyperOS-style launcher with Samsung One UI-style gestures. Kotlin, no heavy libraries, tuned for low-RAM phones.

## Build
Upload to GitHub; the Build APK workflow produces `app-debug.apk` (see Actions > latest run > Artifacts).
The APK is signed with the fixed key in `app/debug.keystore`, so new builds install over old ones.

## Features
- Squircle / circle / rounded-square icons, 4 or 5 column grid, small / medium / large icons
- Home screen with clock + date, page dots, frosted dock
- Folders: long-press an app > Add to folder; tap a folder to open it, rename or delete it
- Widgets page: swipe right from the first home page; long-press the home screen > Add widget; long-press a widget to remove it
- Themes: HyperOS Orange, Ocean Blue, Rose Pink, Forest Green, Light
- Icon packs: any ADW / Nova / Apex style icon pack installed from the Play Store
- App drawer: swipe up on home; search box; swipe down at the top to close
- Edge panel: swipe in from the right edge
- Double-tap empty space to lock, swipe down for notifications (needs the accessibility toggle: long-press home > Enable gestures)
- Long-press an app: folder, home, dock, edge panel, hide, app info, uninstall
- Long-press empty space: add / remove widget, wallpaper, launcher settings, unhide apps

## Not included yet
Drag-and-drop rearranging, weather.
