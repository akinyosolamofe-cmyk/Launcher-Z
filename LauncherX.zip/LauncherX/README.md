# LauncherX

Xiaomi/HyperOS-style launcher with Samsung One UI-style gestures. Kotlin, no heavy libraries, tuned for low-RAM phones (Redmi A3X, Android 14).

## Build
1. Open this folder in Android Studio (Koala or newer) and let Gradle sync.
2. Run on the phone (USB debugging) or Build > Build APK(s).
3. Press Home and choose LauncherX > Always.

## Features
- Squircle icons for every app, 4 or 5 column grid, paged home screen with dots, dock
- App drawer: swipe up on home; search box; swipe down at the top to close
- Edge panel: swipe in from the right edge (add apps via long-press > Add to Edge panel)
- Double-tap empty space to lock, swipe down for notifications (needs the accessibility toggle: long-press home > Enable gestures)
- Long-press an app: add/remove from home, dock, edge panel; hide; app info; uninstall
- Long-press empty space: wallpaper, grid size, gestures, unhide apps, default home settings

## Not included yet
Folders, widgets, icon packs, themes.
