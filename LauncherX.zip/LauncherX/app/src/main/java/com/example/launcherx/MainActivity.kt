package com.example.launcherx

import android.accessibilityservice.AccessibilityService
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    companion object {
        private const val ROWS = 5
        private const val MAX_EDGE = 8
        private const val KEY_HOME = "home"
        private const val KEY_DOCK = "dock"
        private const val KEY_EDGE = "edge"
        private const val KEY_HIDDEN = "hidden"
    }

    private lateinit var prefs: Prefs
    private lateinit var repo: AppRepository

    private var allApps: List<AppInfo> = emptyList()
    private var visibleApps: List<AppInfo> = emptyList()
    private val byKey = HashMap<String, AppInfo>()

    private lateinit var root: FrameLayout
    private lateinit var home: View
    private lateinit var pager: ViewPager2
    private lateinit var dots: LinearLayout
    private lateinit var dock: RecyclerView
    private lateinit var drawer: View
    private lateinit var drawerList: RecyclerView
    private lateinit var search: EditText
    private lateinit var edgeScrim: View
    private lateinit var edgePanel: View
    private lateinit var edgeList: RecyclerView

    private lateinit var dockAdapter: AppAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var edgeAdapter: AppAdapter
    private lateinit var gestures: GestureDetector

    private var drawerOpen = false
    private var edgeOpen = false
    private var drawerAtTopOnDown = true
    private var iconPx = 128

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reload()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        repo = AppRepository(this)
        iconPx = (56 * resources.displayMetrics.density).toInt().coerceIn(96, 192)

        bindViews()
        setupWindowStyle()
        setupAdapters()
        setupDrawer()
        setupGestures()
        setupBack()

        addOnNewIntentListener { intent ->
            if (intent.hasCategory(Intent.CATEGORY_HOME)) {
                closeDrawer(false)
                closeEdge()
                pager.currentItem = 0
            }
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        reload()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        home = findViewById(R.id.home)
        pager = findViewById(R.id.pager)
        dots = findViewById(R.id.dots)
        dock = findViewById(R.id.dock)
        drawer = findViewById(R.id.drawer)
        drawerList = findViewById(R.id.drawer_list)
        search = findViewById(R.id.search)
        edgeScrim = findViewById(R.id.edge_scrim)
        edgePanel = findViewById(R.id.edge_panel)
        edgeList = findViewById(R.id.edge_list)
    }

    private fun setupWindowStyle() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            home.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            drawer.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }
    }

    private fun setupAdapters() {
        pager.offscreenPageLimit = 1
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
            }
        })

        dockAdapter = AppAdapter(R.layout.item_app, false,
            { app, v -> launch(app, v) }, { app -> showMenu(app) })
        dock.layoutManager = GridLayoutManager(this, 4)
        dock.adapter = dockAdapter

        drawerAdapter = AppAdapter(R.layout.item_app, true,
            { app, v -> launch(app, v) }, { app -> showMenu(app) })
        drawerList.layoutManager = GridLayoutManager(this, prefs.cols)
        drawerList.adapter = drawerAdapter

        edgeAdapter = AppAdapter(R.layout.item_edge, false,
            { app, v -> launch(app, v) }, { app -> showMenu(app) })
        edgeList.layoutManager = LinearLayoutManager(this)
        edgeList.adapter = edgeAdapter

        edgeScrim.setOnClickListener { closeEdge() }
    }

    private fun setupDrawer() {
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterDrawer(s?.toString() ?: "")
            }
        })
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                drawerAdapter.items.firstOrNull()?.let { launch(it, search) }
                true
            } else {
                false
            }
        }
    }

    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                drawerAtTopOnDown = !drawerList.canScrollVertically(-1)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!drawerOpen && !edgeOpen && !isOverIcon(e.rawX, e.rawY)) lockScreen()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!drawerOpen && !edgeOpen && !isOverIcon(e.rawX, e.rawY)) showHomeMenu()
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                when {
                    drawerOpen -> {
                        if (dy > dp(80) && abs(dy) > abs(dx) && vy > 800 && drawerAtTopOnDown) {
                            closeDrawer()
                        }
                    }
                    edgeOpen -> {
                        if (dx > dp(60) && abs(dx) > abs(dy)) closeEdge()
                    }
                    e1.x > root.width - dp(28) && dx < -dp(40) && abs(dx) > abs(dy) -> {
                        openEdge()
                    }
                    abs(dy) > abs(dx) && abs(dy) > dp(80) && abs(vy) > 800 -> {
                        if (dy < 0) openDrawer() else openNotifications()
                    }
                }
                return false
            }
        })
    }

    private fun setupBack() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    drawerOpen -> closeDrawer()
                    edgeOpen -> closeEdge()
                    pager.currentItem != 0 -> pager.currentItem = 0
                    else -> {}
                }
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- data

    private fun reload() {
        Thread {
            val apps = repo.load(iconPx)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                allApps = apps
                byKey.clear()
                apps.forEach { byKey[it.key] = it }
                ensureDefaults()
                refresh()
            }
        }.start()
    }

    /** First run: put dialer/messages/browser/camera in the dock and the first apps on the home screen. */
    private fun ensureDefaults() {
        if (prefs.initialized || allApps.isEmpty()) return

        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val dockKeys = LinkedHashSet<String>()
        for (i in intents) {
            val real = i.selector ?: i
            val pkg = packageManager.resolveActivity(real, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName ?: continue
            if (pkg == "android") continue
            allApps.firstOrNull { it.component.packageName == pkg }?.let { dockKeys.add(it.key) }
        }
        val homeKeys = allApps.filter { it.key !in dockKeys }.take(16).map { it.key }
        prefs.setList(KEY_DOCK, dockKeys.toList())
        prefs.setList(KEY_HOME, homeKeys)
        prefs.initialized = true
    }

    private fun refresh() {
        val hidden = prefs.list(KEY_HIDDEN).toSet()
        visibleApps = allApps.filter { it.key !in hidden }

        fun resolve(listKey: String): List<AppInfo> =
            prefs.list(listKey).mapNotNull { byKey[it] }.filter { it.key !in hidden }

        val homeApps = resolve(KEY_HOME)
        val dockApps = resolve(KEY_DOCK).take(prefs.cols)
        val edgeApps = resolve(KEY_EDGE).take(MAX_EDGE)

        val pages = homeApps.chunked(prefs.cols * ROWS).ifEmpty { listOf(emptyList()) }
        pager.adapter = HomePagerAdapter(pages)
        buildDots(pages.size)

        (dock.layoutManager as GridLayoutManager).spanCount = maxOf(1, dockApps.size)
        dockAdapter.submit(dockApps)
        edgeAdapter.submit(edgeApps)

        (drawerList.layoutManager as GridLayoutManager).spanCount = prefs.cols
        filterDrawer(search.text.toString())
    }

    private fun filterDrawer(query: String) {
        val q = query.trim()
        drawerAdapter.submit(if (q.isEmpty()) visibleApps else visibleApps.filter { it.label.contains(q, true) })
    }

    private fun toggle(listKey: String, key: String, add: Boolean) {
        val l = prefs.list(listKey)
        l.remove(key)
        if (add) l.add(key)
        prefs.setList(listKey, l)
        if (add && listKey == KEY_DOCK) removeFrom(KEY_HOME, key)
        if (add && listKey == KEY_HOME) removeFrom(KEY_DOCK, key)
        refresh()
    }

    private fun removeFrom(listKey: String, key: String) {
        val l = prefs.list(listKey)
        if (l.remove(key)) prefs.setList(listKey, l)
    }

    private fun hideApp(key: String) {
        removeFrom(KEY_HOME, key)
        removeFrom(KEY_DOCK, key)
        removeFrom(KEY_EDGE, key)
        val h = prefs.list(KEY_HIDDEN)
        if (key !in h) h.add(key)
        prefs.setList(KEY_HIDDEN, h)
        refresh()
    }

    // ---------------------------------------------------------------- home pager

    private class PageVH(v: RecyclerView, val adapter: AppAdapter) : RecyclerView.ViewHolder(v)

    private inner class HomePagerAdapter(private val pages: List<List<AppInfo>>) :
        RecyclerView.Adapter<PageVH>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageVH {
            val rv = RecyclerView(parent.context)
            rv.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            rv.layoutManager = object : GridLayoutManager(parent.context, prefs.cols) {
                override fun canScrollVertically(): Boolean = false
            }
            rv.overScrollMode = View.OVER_SCROLL_NEVER
            rv.setPadding(dp(8), dp(12), dp(8), 0)
            val ad = AppAdapter(R.layout.item_app, true,
                { app, v -> launch(app, v) }, { app -> showMenu(app) })
            rv.adapter = ad
            return PageVH(rv, ad)
        }

        override fun onBindViewHolder(holder: PageVH, position: Int) {
            holder.adapter.submit(pages[position])
        }

        override fun getItemCount(): Int = pages.size
    }

    private fun buildDots(count: Int) {
        dots.removeAllViews()
        if (count <= 1) {
            dots.visibility = View.INVISIBLE
            return
        }
        dots.visibility = View.VISIBLE
        repeat(count) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dp(6), dp(6))
            lp.setMargins(dp(4), 0, dp(4), 0)
            v.layoutParams = lp
            v.setBackgroundResource(R.drawable.dot)
            dots.addView(v)
        }
        updateDots(pager.currentItem)
    }

    private fun updateDots(selected: Int) {
        for (i in 0 until dots.childCount) {
            dots.getChildAt(i).alpha = if (i == selected) 1f else 0.35f
        }
    }

    // ---------------------------------------------------------------- launching & menus

    private fun launch(app: AppInfo, anchor: View) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(anchor, 0, 0, anchor.width, anchor.height)
            startActivity(intent, opts.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
        closeDrawer(false)
        closeEdge()
    }

    private fun showMenu(app: AppInfo) {
        val key = app.key
        val homeL = prefs.list(KEY_HOME)
        val dockL = prefs.list(KEY_DOCK)
        val edgeL = prefs.list(KEY_EDGE)

        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        fun add(label: String, action: () -> Unit) {
            labels.add(label)
            actions.add(action)
        }

        if (key in homeL) add("Remove from home") { toggle(KEY_HOME, key, false) }
        else add("Add to home") { toggle(KEY_HOME, key, true) }

        if (key in dockL) add("Remove from dock") { toggle(KEY_DOCK, key, false) }
        else if (dockL.size < prefs.cols) add("Add to dock") { toggle(KEY_DOCK, key, true) }

        if (key in edgeL) add("Remove from Edge panel") { toggle(KEY_EDGE, key, false) }
        else if (edgeL.size < MAX_EDGE) add("Add to Edge panel") { toggle(KEY_EDGE, key, true) }

        add("Hide app") { hideApp(key) }
        add("App info") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${app.component.packageName}"))
            )
        }
        add("Uninstall") {
            try {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.component.packageName}")))
            } catch (e: Exception) {
                Toast.makeText(this, "Can't uninstall this app", Toast.LENGTH_SHORT).show()
            }
        }

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun showHomeMenu() {
        val gridLabel = if (prefs.cols == 4) "Grid: switch to 5 columns" else "Grid: switch to 4 columns"
        val items = arrayOf(
            "Wallpaper",
            gridLabel,
            "Enable gestures (double-tap lock, swipe down)",
            "Unhide all apps",
            "Default home app settings"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                try {
                    when (which) {
                        0 -> startActivity(
                            Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")
                        )
                        1 -> {
                            prefs.cols = if (prefs.cols == 4) 5 else 4
                            refresh()
                        }
                        2 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        3 -> {
                            prefs.setList(KEY_HIDDEN, emptyList())
                            refresh()
                        }
                        4 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                        else -> {}
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- drawer & edge panel

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        closeEdge()
        drawerList.scrollToPosition(0)
        drawer.animate().cancel()
        drawer.visibility = View.VISIBLE
        drawer.translationY = root.height.toFloat()
        drawer.alpha = 0f
        drawer.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(220)
            .setInterpolator(DecelerateInterpolator())
            .start()
        home.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(220).start()
    }

    private fun closeDrawer(animate: Boolean = true) {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        search.clearFocus()
        drawer.animate().cancel()
        if (animate) {
            drawer.animate()
                .translationY(root.height.toFloat())
                .alpha(0f)
                .setDuration(200)
                .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
                .start()
        } else {
            drawer.visibility = View.GONE
        }
        home.animate().cancel()
        home.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start()
    }

    private fun openEdge() {
        if (edgeOpen || drawerOpen) return
        if (edgeAdapter.itemCount == 0) {
            Toast.makeText(this, "Long-press an app > Add to Edge panel", Toast.LENGTH_LONG).show()
            return
        }
        edgeOpen = true
        edgeScrim.visibility = View.VISIBLE
        edgePanel.visibility = View.VISIBLE
        edgePanel.translationX = dp(90).toFloat()
        edgePanel.animate().translationX(0f).setDuration(180).start()
    }

    private fun closeEdge() {
        if (!edgeOpen) return
        edgeOpen = false
        edgeScrim.visibility = View.GONE
        edgePanel.animate().translationX(dp(90).toFloat()).setDuration(160)
            .withEndAction { if (!edgeOpen) edgePanel.visibility = View.GONE }
            .start()
    }

    // ---------------------------------------------------------------- system gestures

    private fun lockScreen() {
        val service = GestureService.instance
        if (service != null && Build.VERSION.SDK_INT >= 28) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            needGestureService()
        }
    }

    private fun openNotifications() {
        val service = GestureService.instance
        if (service != null) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        } else {
            needGestureService()
        }
    }

    private fun needGestureService() {
        Toast.makeText(
            this,
            "Long-press the home screen > Enable gestures, then turn on LauncherX",
            Toast.LENGTH_LONG
        ).show()
    }

    // ---------------------------------------------------------------- helpers

    private fun isOverIcon(x: Float, y: Float): Boolean = hitItem(home, x.toInt(), y.toInt())

    private fun hitItem(v: View, x: Int, y: Int): Boolean {
        if (v.visibility != View.VISIBLE) return false
        if (v.id == R.id.item_root) {
            val r = Rect()
            return v.getGlobalVisibleRect(r) && r.contains(x, y)
        }
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                if (hitItem(v.getChildAt(i), x, y)) return true
            }
        }
        return false
    }

    private fun hideKeyboard() {
        ContextCompat.getSystemService(this, InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
