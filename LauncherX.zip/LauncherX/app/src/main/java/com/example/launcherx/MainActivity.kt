package com.example.launcherx

import android.accessibilityservice.AccessibilityService
import android.app.ActivityOptions
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

class MainActivity : AppCompatActivity() {

    companion object {
        private const val MAX_EDGE = 8
        private const val KEY_HOME = "home"
        private const val KEY_DOCK = "dock"
        private const val KEY_EDGE = "edge"
        private const val KEY_HIDDEN = "hidden"
        private const val KEY_WIDGETS = "widgets"
        private const val FOLDER_PREFIX = "folder:"
        private const val HOST_ID = 1024
        private const val REQ_BIND = 101
        private const val REQ_CONFIGURE = 102
        private val SHAPE_NAMES = arrayOf("Squircle (Xiaomi)", "Circle", "Rounded square")
        private val SIZE_NAMES = arrayOf("Small", "Medium", "Large")
    }

    private lateinit var prefs: Prefs
    private lateinit var repo: AppRepository
    private lateinit var folders: FolderStore
    private lateinit var style: Style
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetManager: AppWidgetManager

    private var allApps: List<AppInfo> = emptyList()
    private var visibleApps: List<AppInfo> = emptyList()
    private val byKey = HashMap<String, AppInfo>()

    private lateinit var root: FrameLayout
    private lateinit var home: View
    private lateinit var clockBox: View
    private lateinit var pager: ViewPager2
    private lateinit var dots: LinearLayout
    private lateinit var dock: RecyclerView
    private lateinit var drawer: View
    private lateinit var drawerList: RecyclerView
    private lateinit var search: EditText
    private lateinit var edgeScrim: View
    private lateinit var edgePanel: View
    private lateinit var edgeList: RecyclerView

    private lateinit var dockAdapter: AppAdapter
    private lateinit var drawerAdapter: AppAdapter
    private lateinit var edgeAdapter: AppAdapter
    private lateinit var gestures: GestureDetector

    private var folderDialog: AlertDialog? = null
    private var drawerOpen = false
    private var edgeOpen = false
    private var drawerAtTopOnDown = true
    private var pagerReady = false
    private var lastRows = 0
    private var pendingWidgetId = -1

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            reload()
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        prefs = Prefs(this)
        repo = AppRepository(this)
        folders = FolderStore(prefs)
        style = Themes.get(prefs.theme)
        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost = AppWidgetHost(this, HOST_ID)

        bindViews()
        setupWindowStyle()
        setupAdapters()
        setupDrawer()
        setupGestures()
        setupBack()
        applyTheme()

        addOnNewIntentListener { intent ->
            if (intent.hasCategory(Intent.CATEGORY_HOME)) {
                closeDrawer(false)
                closeEdge()
                folderDialog?.dismiss()
                pager.currentItem = 1
            }
        }

        val filter = IntentFilter()
        filter.addAction(Intent.ACTION_PACKAGE_ADDED)
        filter.addAction(Intent.ACTION_PACKAGE_REMOVED)
        filter.addAction(Intent.ACTION_PACKAGE_CHANGED)
        filter.addDataScheme("package")
        ContextCompat.registerReceiver(this, pkgReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        reload()
    }

    override fun onStart() {
        super.onStart()
        try {
            widgetHost.startListening()
        } catch (e: Exception) {
            // widgets are optional
        }
    }

    override fun onStop() {
        super.onStop()
        try {
            widgetHost.stopListening()
        } catch (e: Exception) {
            // ignore
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
            // already unregistered
        }
    }

    // ---------------------------------------------------------------- setup

    private fun bindViews() {
        root = findViewById(R.id.root)
        home = findViewById(R.id.home)
        clockBox = findViewById(R.id.clock_box)
        pager = findViewById(R.id.pager)
        dots = findViewById(R.id.dots)
        dock = findViewById(R.id.dock)
        drawer = findViewById(R.id.drawer)
        drawerList = findViewById(R.id.drawer_list)
        search = findViewById(R.id.search)
        edgeScrim = findViewById(R.id.edge_scrim)
        edgePanel = findViewById(R.id.edge_panel)
        edgeList = findViewById(R.id.edge_list)
    }

    private fun setupWindowStyle() {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.isAppearanceLightStatusBars = false
        controller.isAppearanceLightNavigationBars = false
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            home.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            drawer.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }
    }

    private fun setupAdapters() {
        pager.offscreenPageLimit = 1
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateDots(position)
                if (prefs.clock) {
                    clockBox.visibility = if (position == 0) View.INVISIBLE else View.VISIBLE
                }
            }
        })
        // Work out how many rows fit once the pager knows its real height
        pager.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (allApps.isNotEmpty() && rowsPerPage() != lastRows) {
                pager.post { refresh() }
            }
        }

        dockAdapter = AppAdapter(R.layout.item_app, { false }, { Color.WHITE }, { iconDp() },
            { app, v -> launch(app, v) }, { app -> showMenu(app) })
        dock.layoutManager = GridLayoutManager(this, 4)
        dock.adapter = dockAdapter

        drawerAdapter = AppAdapter(R.layout.item_app, { true }, { style.drawerText }, { iconDp() },
            { app, v -> launch(app, v) }, { app -> showMenu(app) })
        drawerList.layoutManager = GridLayoutManager(this, prefs.cols)
        drawerList.adapter = drawerAdapter

        edgeAdapter = AppAdapter(R.layout.item_edge, { false }, { Color.WHITE }, { 46 },
            { app, v -> launch(app, v) }, { app -> showMenu(app) })
        edgeList.layoutManager = LinearLayoutManager(this)
        edgeList.adapter = edgeAdapter

        edgeScrim.setOnClickListener { closeEdge() }
    }

    private fun setupDrawer() {
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                filterDrawer(s?.toString() ?: "")
            }
        })
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                drawerAdapter.items.firstOrNull()?.let { launch(it, search) }
                true
            } else {
                false
            }
        }
    }

    private fun setupGestures() {
        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                drawerAtTopOnDown = !drawerList.canScrollVertically(-1)
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (!drawerOpen && !edgeOpen && !isOverIcon(e.rawX, e.rawY)) lockScreen()
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!drawerOpen && !edgeOpen && !isOverIcon(e.rawX, e.rawY)) showHomeMenu()
            }

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                when {
                    drawerOpen -> {
                        if (dy > dp(80) && abs(dy) > abs(dx) && vy > 800 && drawerAtTopOnDown) {
                            closeDrawer()
                        }
                    }
                    edgeOpen -> {
                        if (dx > dp(60) && abs(dx) > abs(dy)) closeEdge()
                    }
                    e1.x > root.width - dp(28) && dx < -dp(40) && abs(dx) > abs(dy) -> {
                        openEdge()
                    }
                    // vertical swipes are ignored on the widgets page so it can scroll
                    pager.currentItem != 0 && abs(dy) > abs(dx) && abs(dy) > dp(80) && abs(vy) > 800 -> {
                        if (dy < 0) openDrawer() else openNotifications()
                    }
                }
                return false
            }
        })
    }

    private fun setupBack() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    drawerOpen -> closeDrawer()
                    edgeOpen -> closeEdge()
                    pager.currentItem != 1 -> pager.currentItem = 1
                    else -> {}
                }
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------------------------------------------------------------- theme

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        return g
    }

    private fun applyTheme() {
        style = Themes.get(prefs.theme)
        dock.background = rounded(style.dock, 30)
        drawer.setBackgroundColor(style.drawer)
        search.background = rounded(style.search, 23)
        search.setTextColor(style.drawerText)
        search.setHintTextColor(style.drawerHint)

        val r = dp(28).toFloat()
        val edgeBg = GradientDrawable()
        edgeBg.setColor(style.edge)
        edgeBg.cornerRadii = floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r)
        edgePanel.background = edgeBg

        clockBox.visibility = if (prefs.clock) View.VISIBLE else View.GONE
        updateDots(if (pagerReady) pager.currentItem else 1)
    }

    // ---------------------------------------------------------------- data

    private fun iconDp(): Int = when (prefs.iconSize) {
        0 -> 48
        2 -> 64
        else -> 56
    }

    private fun reload() {
        val px = (iconDp() * resources.displayMetrics.density).toInt()
        val radius = IconShaper.radiusFor(prefs.shape)
        val pack = prefs.iconPack
        Thread {
            val apps = repo.load(px, radius, pack)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                allApps = apps
                byKey.clear()
                apps.forEach { byKey[it.key] = it }
                ensureDefaults()
                refresh()
            }
        }.start()
    }

    /** First run: put dialer/messages/browser/camera in the dock and the first apps on the home screen. */
    private fun ensureDefaults() {
        if (prefs.initialized || allApps.isEmpty()) return

        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING),
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER),
            Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        )
        val dockKeys = LinkedHashSet<String>()
        for (i in intents) {
            val real = i.selector ?: i
            val pkg = packageManager.resolveActivity(real, PackageManager.MATCH_DEFAULT_ONLY)
                ?.activityInfo?.packageName ?: continue
            if (pkg == "android") continue
            allApps.firstOrNull { it.component.packageName == pkg }?.let { dockKeys.add(it.key) }
        }
        val homeKeys = allApps.filter { it.key !in dockKeys }.take(16).map { it.key }
        prefs.setList(KEY_DOCK, dockKeys.toList())
        prefs.setList(KEY_HOME, homeKeys)
        prefs.initialized = true
    }

    private fun rowsPerPage(): Int {
        val h = pager.height
        if (h <= 0) return 5
        val itemH = dp(iconDp() + (if (prefs.labels) 36 else 20))
        return ((h - dp(12)) / itemH).coerceIn(3, 7)
    }

    /** Turns the saved home list (apps and "folder:id" entries) into tiles. */
    private fun resolveHome(hidden: Set<String>): List<AppInfo> {
        val out = ArrayList<AppInfo>()
        val iconPx = (iconDp() * resources.displayMetrics.density).toInt()
        val folderIds = folders.ids()
        for (k in prefs.list(KEY_HOME)) {
            if (k.startsWith(FOLDER_PREFIX)) {
                val id = k.removePrefix(FOLDER_PREFIX)
                if (id !in folderIds) continue
                val inside = folders.apps(id).mapNotNull { byKey[it] }.filter { it.key !in hidden }
                val icon = FolderIcon.make(inside.map { it.icon }, iconPx, style.folder)
                out.add(AppInfo(folders.name(id), ComponentName("folder", "folder"), icon, id))
            } else {
                val a = byKey[k]
                if (a != null && a.key !in hidden) out.add(a)
            }
        }
        return out
    }

    private fun refresh() {
        val hidden = prefs.list(KEY_HIDDEN).toSet()
        visibleApps = allApps.filter { it.key !in hidden }

        val homeItems = resolveHome(hidden)
        val dockApps = prefs.list(KEY_DOCK).mapNotNull { byKey[it] }.filter { it.key !in hidden }.take(prefs.cols)
        val edgeApps = prefs.list(KEY_EDGE).mapNotNull { byKey[it] }.filter { it.key !in hidden }.take(MAX_EDGE)

        val rows = rowsPerPage()
        lastRows = rows
        val pages = homeItems.chunked(prefs.cols * rows).ifEmpty { listOf(emptyList()) }

        // page 0 is the widgets page, app pages start at 1
        val keep = if (pagerReady) pager.currentItem else 1
        pager.adapter = HomePagerAdapter(pages)
        pager.setCurrentItem(keep.coerceIn(0, pages.size), false)
        pagerReady = true
        buildDots(pages.size + 1)

        (dock.layoutManager as GridLayoutManager).spanCount = maxOf(1, dockApps.size)
        dockAdapter.submit(dockApps)
        edgeAdapter.submit(edgeApps)

        (drawerList.layoutManager as GridLayoutManager).spanCount = prefs.cols
        filterDrawer(search.text.toString())
    }

    private fun filterDrawer(query: String) {
        val q = query.trim()
        drawerAdapter.submit(if (q.isEmpty()) visibleApps else visibleApps.filter { it.label.contains(q, true) })
    }

    private fun removeFrom(listKey: String, key: String) {
        val l = prefs.list(listKey)
        if (l.remove(key)) prefs.setList(listKey, l)
    }

    private fun toggle(listKey: String, key: String, add: Boolean) {
        val l = prefs.list(listKey)
        l.remove(key)
        if (add) l.add(key)
        prefs.setList(listKey, l)
        if (add && (listKey == KEY_HOME || listKey == KEY_DOCK)) removeKeyFromFolders(key)
        if (add && listKey == KEY_DOCK) removeFrom(KEY_HOME, key)
        if (add && listKey == KEY_HOME) removeFrom(KEY_DOCK, key)
        refresh()
    }

    private fun hideApp(key: String) {
        removeFrom(KEY_HOME, key)
        removeFrom(KEY_DOCK, key)
        removeFrom(KEY_EDGE, key)
        removeKeyFromFolders(key)
        val h = prefs.list(KEY_HIDDEN)
        if (key !in h) h.add(key)
        prefs.setList(KEY_HIDDEN, h)
        refresh()
    }

    // ---------------------------------------------------------------- home pager

    private class AppPageVH(v: RecyclerView, val adapter: AppAdapter) : RecyclerView.ViewHolder(v)

    private class WidgetPageVH(val scroll: ScrollView, val box: LinearLayout) : RecyclerView.ViewHolder(scroll)

    private inner class HomePagerAdapter(private val pages: List<List<AppInfo>>) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun getItemViewType(position: Int): Int = if (position == 0) 0 else 1

        override fun getItemCount(): Int = pages.size + 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            if (viewType == 0) {
                val scroll = ScrollView(parent.context)
                scroll.layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
                )
                scroll.isVerticalScrollBarEnabled = false
                scroll.overScrollMode = View.OVER_SCROLL_NEVER
                val box = LinearLayout(parent.context)
                box.orientation = LinearLayout.VERTICAL
                box.setPadding(dp(14), dp(16), dp(14), dp(24))
                scroll.addView(
                    box,
                    FrameLayout.LayoutParams(
                        FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT
                    )
                )
                return WidgetPageVH(scroll, box)
            }

            val rv = RecyclerView(parent.context)
            rv.layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
            rv.layoutManager = object : GridLayoutManager(parent.context, prefs.cols) {
                override fun canScrollVertically(): Boolean = false
            }
            rv.overScrollMode = View.OVER_SCROLL_NEVER
            rv.setPadding(dp(8), dp(4), dp(8), 0)
            val ad = AppAdapter(R.layout.item_app, { prefs.labels }, { Color.WHITE }, { iconDp() },
                { app, v -> launch(app, v) }, { app -> showMenu(app) })
            rv.adapter = ad
            return AppPageVH(rv, ad)
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            if (holder is AppPageVH) {
                holder.adapter.submit(pages[position - 1])
            } else if (holder is WidgetPageVH) {
                fillWidgetPage(holder.box)
            }
        }
    }

    private fun buildDots(count: Int) {
        dots.removeAllViews()
        if (count <= 1) {
            dots.visibility = View.INVISIBLE
            return
        }
        dots.visibility = View.VISIBLE
        repeat(count) {
            val v = View(this)
            val lp = LinearLayout.LayoutParams(dp(6), dp(6))
            lp.setMargins(dp(4), 0, dp(4), 0)
            v.layoutParams = lp
            v.setBackgroundResource(R.drawable.dot)
            dots.addView(v)
        }
        updateDots(pager.currentItem)
    }

    private fun updateDots(selected: Int) {
        for (i in 0 until dots.childCount) {
            val d = dots.getChildAt(i)
            d.background?.mutate()?.setTint(if (i == selected) style.accent else Color.WHITE)
            d.alpha = if (i == selected) 1f else 0.4f
        }
    }

    // ---------------------------------------------------------------- widgets

    private fun fillWidgetPage(box: LinearLayout) {
        box.removeAllViews()

        val title = TextView(this)
        title.text = "Widgets"
        title.setTextColor(Color.WHITE)
        title.textSize = 22f
        title.setPadding(dp(4), dp(8), 0, dp(12))
        box.addView(title)

        val saved = prefs.list(KEY_WIDGETS)
        val valid = ArrayList<String>()
        val widthDp = (resources.displayMetrics.widthPixels / resources.displayMetrics.density).toInt()

        for (s in saved) {
            val id = s.toIntOrNull() ?: continue
            val info = widgetManager.getAppWidgetInfo(id)
            if (info == null) {
                widgetHost.deleteAppWidgetId(id)
                continue
            }
            val hv: AppWidgetHostView = try {
                widgetHost.createView(this, id, info)
            } catch (e: Exception) {
                null
            } ?: continue
            valid.add(s)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, maxOf(info.minHeight, dp(80))
            )
            lp.bottomMargin = dp(10)
            hv.setOnLongClickListener {
                confirmRemoveWidget(id)
                true
            }
            box.addView(hv, lp)
            val hDp = (info.minHeight / resources.displayMetrics.density).toInt()
            hv.updateAppWidgetSize(Bundle(), widthDp - 28, hDp, widthDp - 28, hDp)
        }
        if (valid.size != saved.size) prefs.setList(KEY_WIDGETS, valid)

        val add = TextView(this)
        add.text = "+  Add widget"
        add.setTextColor(Color.WHITE)
        add.textSize = 15f
        add.gravity = Gravity.CENTER
        add.background = rounded(style.dock, 24)
        add.setOnClickListener { showAddWidget() }
        val alp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(48)
        )
        alp.topMargin = dp(6)
        box.addView(add, alp)
    }

    private fun showAddWidget() {
        val providers = widgetManager.installedProviders.sortedBy { it.loadLabel(packageManager).lowercase() }
        if (providers.isEmpty()) {
            Toast.makeText(this, "No widgets found on this phone", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = providers.map { it.loadLabel(packageManager) }
        AlertDialog.Builder(this)
            .setTitle("Add widget")
            .setItems(labels.toTypedArray()) { _, which ->
                val p = providers[which]
                val id = widgetHost.allocateAppWidgetId()
                if (widgetManager.bindAppWidgetIdIfAllowed(id, p.provider)) {
                    configureOrAdd(id)
                } else {
                    pendingWidgetId = id
                    val i = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                    i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, p.provider)
                    try {
                        @Suppress("DEPRECATION")
                        startActivityForResult(i, REQ_BIND)
                    } catch (e: Exception) {
                        widgetHost.deleteAppWidgetId(id)
                        Toast.makeText(this, "Can't add this widget", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun configureOrAdd(id: Int) {
        pendingWidgetId = id
        val info = widgetManager.getAppWidgetInfo(id)
        if (info != null && info.configure != null) {
            try {
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIGURE, null)
            } catch (e: Exception) {
                addWidget(id)
            }
        } else {
            addWidget(id)
        }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_BIND && requestCode != REQ_CONFIGURE) return
        val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
        if (id == -1) return
        if (resultCode != RESULT_OK) {
            widgetHost.deleteAppWidgetId(id)
            return
        }
        if (requestCode == REQ_BIND) configureOrAdd(id) else addWidget(id)
    }

    private fun addWidget(id: Int) {
        val l = prefs.list(KEY_WIDGETS)
        l.add(id.toString())
        prefs.setList(KEY_WIDGETS, l)
        pendingWidgetId = -1
        refresh()
        pager.setCurrentItem(0, false)
    }

    private fun confirmRemoveWidget(id: Int) {
        AlertDialog.Builder(this)
            .setTitle("Remove this widget?")
            .setPositiveButton("Remove") { _, _ -> removeWidget(id) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun removeWidget(id: Int) {
        widgetHost.deleteAppWidgetId(id)
        removeFrom(KEY_WIDGETS, id.toString())
        refresh()
    }

    private fun showRemoveWidgetList() {
        val ids = prefs.list(KEY_WIDGETS).mapNotNull { it.toIntOrNull() }
        if (ids.isEmpty()) {
            Toast.makeText(this, "No widgets added yet", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = ids.map { widgetManager.getAppWidgetInfo(it)?.loadLabel(packageManager) ?: "Widget" }
        AlertDialog.Builder(this)
            .setTitle("Remove widget")
            .setItems(labels.toTypedArray()) { _, which -> removeWidget(ids[which]) }
            .show()
    }

    // ---------------------------------------------------------------- folders

    private fun removeKeyFromFolders(key: String) {
        for (id in folders.ids()) {
            val l = folders.apps(id)
            if (l.remove(key)) {
                folders.setApps(id, l)
                if (l.isEmpty()) dropFolder(id)
            }
        }
    }

    private fun dropFolder(id: String) {
        folders.delete(id)
        removeFrom(KEY_HOME, FOLDER_PREFIX + id)
    }

    private fun placeInFolder(key: String, id: String) {
        removeKeyFromFolders(key)
        val homeList = prefs.list(KEY_HOME)
        val idx = homeList.indexOf(key)
        homeList.remove(key)
        val fk = FOLDER_PREFIX + id
        if (!homeList.contains(fk)) {
            if (idx >= 0) homeList.add(minOf(idx, homeList.size), fk) else homeList.add(fk)
        }
        prefs.setList(KEY_HOME, homeList)
        removeFrom(KEY_DOCK, key)
        val inside = folders.apps(id)
        if (!inside.contains(key)) inside.add(key)
        folders.setApps(id, inside)
        refresh()
    }

    private fun chooseFolder(key: String) {
        val ids = folders.ids()
        val labels = ids.map { folders.name(it) } + "New folder..."
        AlertDialog.Builder(this)
            .setTitle("Add to folder")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == ids.size) newFolder(key) else placeInFolder(key, ids[which])
            }
            .show()
    }

    private fun newFolder(key: String) {
        val input = EditText(this)
        input.setText("Folder")
        input.setSelectAllOnFocus(true)
        AlertDialog.Builder(this)
            .setTitle("Folder name")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim().ifEmpty { "Folder" }
                val id = folders.create(name)
                placeInFolder(key, id)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun renameFolder(id: String) {
        val input = EditText(this)
        input.setText(folders.name(id))
        input.setSelectAllOnFocus(true)
        AlertDialog.Builder(this)
            .setTitle("Rename folder")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                folders.setName(id, input.text.toString().trim().ifEmpty { "Folder" })
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun removeFromFolder(key: String, id: String) {
        val l = folders.apps(id)
        l.remove(key)
        folders.setApps(id, l)
        val homeList = prefs.list(KEY_HOME)
        if (!homeList.contains(key)) homeList.add(key)
        prefs.setList(KEY_HOME, homeList)
        if (l.isEmpty()) dropFolder(id)
        refresh()
    }

    private fun deleteFolder(id: String) {
        val homeList = prefs.list(KEY_HOME)
        for (k in folders.apps(id)) {
            if (!homeList.contains(k)) homeList.add(k)
        }
        prefs.setList(KEY_HOME, homeList)
        dropFolder(id)
        refresh()
    }

    private fun openFolder(id: String) {
        val hidden = prefs.list(KEY_HIDDEN).toSet()
        val apps = folders.apps(id).mapNotNull { byKey[it] }.filter { it.key !in hidden }

        val rv = RecyclerView(this)
        rv.layoutManager = GridLayoutManager(this, 4)
        rv.setPadding(dp(8), dp(8), dp(8), dp(8))

        var dialog: AlertDialog? = null
        val ad = AppAdapter(R.layout.item_app, { true }, { Color.parseColor("#222222") }, { iconDp() },
            { app, v ->
                dialog?.dismiss()
                launch(app, v)
            },
            { app -> showMenu(app) })
        rv.adapter = ad
        ad.submit(apps)

        val d = AlertDialog.Builder(this)
            .setTitle(folders.name(id))
            .setView(rv)
            .setPositiveButton("Close", null)
            .setNeutralButton("Rename") { _, _ -> renameFolder(id) }
            .create()
        dialog = d
        folderDialog = d
        d.show()
    }

    // ---------------------------------------------------------------- launching & menus

    private fun launch(app: AppInfo, anchor: View) {
        val fid = app.folderId
        if (fid != null) {
            openFolder(fid)
            return
        }
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val opts = ActivityOptions.makeScaleUpAnimation(anchor, 0, 0, anchor.width, anchor.height)
            startActivity(intent, opts.toBundle())
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open ${app.label}", Toast.LENGTH_SHORT).show()
        }
        closeDrawer(false)
        closeEdge()
    }

    private fun showMenu(app: AppInfo) {
        val fid = app.folderId
        if (fid != null) {
            AlertDialog.Builder(this)
                .setTitle(app.label)
                .setItems(arrayOf("Rename folder", "Delete folder (keep apps)")) { _, which ->
                    if (which == 0) renameFolder(fid) else deleteFolder(fid)
                }
                .show()
            return
        }

        val key = app.key
        val homeL = prefs.list(KEY_HOME)
        val dockL = prefs.list(KEY_DOCK)
        val edgeL = prefs.list(KEY_EDGE)
        val inFolder = folders.folderOf(key)

        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        fun add(label: String, action: () -> Unit) {
            labels.add(label)
            actions.add(action)
        }

        if (inFolder != null) {
            add("Remove from folder") {
                folderDialog?.dismiss()
                removeFromFolder(key, inFolder)
            }
        } else {
            add("Add to folder...") { chooseFolder(key) }
        }

        if (key in homeL) add("Remove from home") { toggle(KEY_HOME, key, false) }
        else add("Add to home") {
            folderDialog?.dismiss()
            toggle(KEY_HOME, key, true)
        }

        if (key in dockL) add("Remove from dock") { toggle(KEY_DOCK, key, false) }
        else if (dockL.size < prefs.cols) add("Add to dock") {
            folderDialog?.dismiss()
            toggle(KEY_DOCK, key, true)
        }

        if (key in edgeL) add("Remove from Edge panel") { toggle(KEY_EDGE, key, false) }
        else if (edgeL.size < MAX_EDGE) add("Add to Edge panel") { toggle(KEY_EDGE, key, true) }

        add("Hide app") {
            folderDialog?.dismiss()
            hideApp(key)
        }
        add("App info") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                    .setData(Uri.parse("package:${app.component.packageName}"))
            )
        }
        add("Uninstall") {
            try {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.component.packageName}")))
            } catch (e: Exception) {
                Toast.makeText(this, "Can't uninstall this app", Toast.LENGTH_SHORT).show()
            }
        }

        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun showHomeMenu() {
        val items = arrayOf(
            "Add widget",
            "Remove a widget",
            "Wallpaper",
            "Launcher settings",
            "Enable gestures (double-tap lock, swipe down)",
            "Unhide all apps",
            "Default home app settings"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                try {
                    when (which) {
                        0 -> showAddWidget()
                        1 -> showRemoveWidgetList()
                        2 -> startActivity(
                            Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper")
                        )
                        3 -> showSettings()
                        4 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                        5 -> {
                            prefs.setList(KEY_HIDDEN, emptyList())
                            refresh()
                        }
                        6 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                        else -> {}
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    // ---------------------------------------------------------------- settings

    private fun onOff(b: Boolean): String = if (b) "On" else "Off"

    private fun showSettings() {
        val packLabel = if (prefs.iconPack.isEmpty()) "None" else
            (repo.findIconPacks().firstOrNull { it.first == prefs.iconPack }?.second ?: prefs.iconPack)
        val items = arrayOf(
            "Theme: ${style.name}",
            "Icon shape: ${SHAPE_NAMES[prefs.shape.coerceIn(0, 2)]}",
            "Icon size: ${SIZE_NAMES[prefs.iconSize.coerceIn(0, 2)]}",
            "Grid columns: ${prefs.cols}",
            "Icon pack: $packLabel",
            "Home labels: ${onOff(prefs.labels)}",
            "Clock on home: ${onOff(prefs.clock)}"
        )
        AlertDialog.Builder(this)
            .setTitle("Launcher settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pickTheme()
                    1 -> pickShape()
                    2 -> pickSize()
                    3 -> pickColumns()
                    4 -> pickIconPack()
                    5 -> {
                        prefs.labels = !prefs.labels
                        refresh()
                    }
                    6 -> {
                        prefs.clock = !prefs.clock
                        applyTheme()
                        refresh()
                    }
                    else -> {}
                }
            }
            .show()
    }

    private fun pickTheme() {
        val names = Themes.all.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Theme")
            .setSingleChoiceItems(names, prefs.theme.coerceIn(0, names.size - 1)) { d, which ->
                prefs.theme = which
                applyTheme()
                refresh()
                d.dismiss()
            }
            .show()
    }

    private fun pickShape() {
        AlertDialog.Builder(this)
            .setTitle("Icon shape")
            .setSingleChoiceItems(SHAPE_NAMES, prefs.shape.coerceIn(0, 2)) { d, which ->
                prefs.shape = which
                reload()
                d.dismiss()
            }
            .show()
    }

    private fun pickSize() {
        AlertDialog.Builder(this)
            .setTitle("Icon size")
            .setSingleChoiceItems(SIZE_NAMES, prefs.iconSize.coerceIn(0, 2)) { d, which ->
                prefs.iconSize = which
                reload()
                d.dismiss()
            }
            .show()
    }

    private fun pickColumns() {
        val names = arrayOf("4 columns", "5 columns")
        AlertDialog.Builder(this)
            .setTitle("Grid columns")
            .setSingleChoiceItems(names, if (prefs.cols == 5) 1 else 0) { d, which ->
                prefs.cols = if (which == 1) 5 else 4
                refresh()
                d.dismiss()
            }
            .show()
    }

    private fun pickIconPack() {
        val packs = repo.findIconPacks()
        if (packs.isEmpty()) {
            Toast.makeText(
                this,
                "No icon packs installed. Install one from the Play Store, then come back.",
                Toast.LENGTH_LONG
            ).show()
            if (prefs.iconPack.isEmpty()) return
        }
        val names = (listOf("None (default icons)") + packs.map { it.second }).toTypedArray()
        val current = packs.indexOfFirst { it.first == prefs.iconPack } + 1
        AlertDialog.Builder(this)
            .setTitle("Icon pack")
            .setSingleChoiceItems(names, current) { d, which ->
                prefs.iconPack = if (which == 0) "" else packs[which - 1].first
                reload()
                d.dismiss()
            }
            .show()
    }

    // ---------------------------------------------------------------- drawer & edge panel

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        closeEdge()
        drawerList.scrollToPosition(0)
        drawer.animate().cancel()
        drawer.visibility = View.VISIBLE
        drawer.translationY = root.height.toFloat()
        drawer.alpha = 0f
        drawer.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(220)
            .setInterpolator(DecelerateInterpolator())
            .start()
        home.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(220).start()
    }

    private fun closeDrawer(animate: Boolean = true) {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        search.clearFocus()
        drawer.animate().cancel()
        if (animate) {
            drawer.animate()
                .translationY(root.height.toFloat())
                .alpha(0f)
                .setDuration(200)
                .withEndAction { if (!drawerOpen) drawer.visibility = View.GONE }
                .start()
        } else {
            drawer.visibility = View.GONE
        }
        home.animate().cancel()
        home.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start()
    }

    private fun openEdge() {
        if (edgeOpen || drawerOpen) return
        if (edgeAdapter.itemCount == 0) {
            Toast.makeText(this, "Long-press an app > Add to Edge panel", Toast.LENGTH_LONG).show()
            return
        }
        edgeOpen = true
        edgeScrim.visibility = View.VISIBLE
        edgePanel.visibility = View.VISIBLE
        edgePanel.translationX = dp(90).toFloat()
        edgePanel.animate().translationX(0f).setDuration(180).start()
    }

    private fun closeEdge() {
        if (!edgeOpen) return
        edgeOpen = false
        edgeScrim.visibility = View.GONE
        edgePanel.animate().translationX(dp(90).toFloat()).setDuration(160)
            .withEndAction { if (!edgeOpen) edgePanel.visibility = View.GONE }
            .start()
    }

    // ---------------------------------------------------------------- system gestures

    private fun lockScreen() {
        val service = GestureService.instance
        if (service != null && Build.VERSION.SDK_INT >= 28) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
        } else {
            needGestureService()
        }
    }

    private fun openNotifications() {
        val service = GestureService.instance
        if (service != null) {
            service.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
        } else {
            needGestureService()
        }
    }

    private fun needGestureService() {
        Toast.makeText(
            this,
            "Long-press the home screen > Enable gestures, then turn on Launcher Zero Two",
            Toast.LENGTH_LONG
        ).show()
    }

    // ---------------------------------------------------------------- helpers

    private fun isOverIcon(x: Float, y: Float): Boolean = hitItem(home, x.toInt(), y.toInt())

    /** True when the point is on an app tile or a widget, so long-press / double-tap leave it alone. */
    private fun hitItem(v: View, x: Int, y: Int): Boolean {
        if (v.visibility != View.VISIBLE) return false
        if (v.id == R.id.item_root || v is AppWidgetHostView) {
            val r = Rect()
            return v.getGlobalVisibleRect(r) && r.contains(x, y)
        }
        if (v is ViewGroup) {
            for (i in 0 until v.childCount) {
                if (hitItem(v.getChildAt(i), x, y)) return true
            }
        }
        return false
    }

    private fun hideKeyboard() {
        ContextCompat.getSystemService(this, InputMethodManager::class.java)
            ?.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
