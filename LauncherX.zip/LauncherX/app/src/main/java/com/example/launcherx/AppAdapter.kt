package com.example.launcherx

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Shows apps and folders. Label visibility, label colour and icon size are read
 * every time a tile is bound, so settings changes only need a refresh.
 */
class AppAdapter(
    private val layout: Int,
    private val showLabel: () -> Boolean,
    private val labelColor: () -> Int,
    private val iconDp: () -> Int,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLong: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    var items: List<AppInfo> = emptyList()
        private set

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView? = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.icon.setImageBitmap(app.icon)

        val px = (iconDp() * holder.itemView.resources.displayMetrics.density).toInt()
        val lp = holder.icon.layoutParams
        if (lp.width != px || lp.height != px) {
            lp.width = px
            lp.height = px
            holder.icon.layoutParams = lp
        }

        val tv = holder.label
        if (tv != null) {
            tv.visibility = if (showLabel()) View.VISIBLE else View.GONE
            tv.text = app.label
            tv.setTextColor(labelColor())
        }
        holder.itemView.setOnClickListener { onClick(app, holder.icon) }
        holder.itemView.setOnLongClickListener {
            onLong(app)
            true
        }
    }
}
