package com.example.launcherx

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val layout: Int,
    private val showLabel: Boolean,
    private val onClick: (AppInfo, View) -> Unit,
    private val onLong: (AppInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    var items: List<AppInfo> = emptyList()
        private set

    @SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<AppInfo>) {
        items = list
        notifyDataSetChanged()
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView? = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(layout, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val app = items[position]
        holder.icon.setImageBitmap(app.icon)
        holder.label?.let {
            it.visibility = if (showLabel) View.VISIBLE else View.GONE
            it.text = app.label
        }
        holder.itemView.setOnClickListener { onClick(app, holder.icon) }
        holder.itemView.setOnLongClickListener {
            onLong(app)
            true
        }
    }
}
