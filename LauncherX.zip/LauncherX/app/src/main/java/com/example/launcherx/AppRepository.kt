package com.example.launcherx

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build

class AppRepository(private val ctx: Context) {

    private val pm: PackageManager = ctx.packageManager

    @Suppress("DEPRECATION")
    fun queryActivities(intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            pm.queryIntentActivities(intent, 0)
        }

    /** Loads all launchable apps. Call from a background thread. */
    fun load(iconPx: Int, radius: Float, packPkg: String): List<AppInfo> {
        var pack: IconPack? = null
        if (packPkg.isNotEmpty()) {
            try {
                pack = IconPack(ctx, packPkg)
            } catch (e: Exception) {
                pack = null
            }
        }

        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val result = ArrayList<AppInfo>()
        for (ri in queryActivities(intent)) {
            if (ri.activityInfo.packageName == ctx.packageName) continue
            val comp = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            val packIcon = pack?.drawableFor(comp)
            val icon = if (packIcon != null) {
                IconShaper.raw(packIcon, iconPx)
            } else {
                IconShaper.shape(ri.loadIcon(pm), iconPx, radius)
            }
            result.add(AppInfo(ri.loadLabel(pm).toString(), comp, icon))
        }
        return result.sortedBy { it.label.lowercase() }
    }

    /** Installed icon packs as (package, label) pairs. */
    fun findIconPacks(): List<Pair<String, String>> {
        val actions = listOf(
            "org.adw.launcher.THEMES",
            "com.novalauncher.THEME",
            "com.gau.go.launcherex.theme",
            "com.anddoes.launcher.THEME"
        )
        val found = LinkedHashMap<String, String>()
        for (a in actions) {
            for (ri in queryActivities(Intent(a))) {
                val p = ri.activityInfo.packageName
                if (!found.containsKey(p)) found[p] = ri.loadLabel(pm).toString()
            }
        }
        return found.map { Pair(it.key, it.value) }.sortedBy { it.second.lowercase() }
    }
}
