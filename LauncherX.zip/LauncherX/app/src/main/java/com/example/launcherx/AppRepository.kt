package com.example.launcherx

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.os.Build

class AppRepository(private val ctx: Context) {

    private val pm: PackageManager = ctx.packageManager

    @Suppress("DEPRECATION")
    private fun query(intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            pm.queryIntentActivities(intent, 0)
        }

    /** Loads all launchable apps. Call from a background thread. */
    fun load(iconPx: Int): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return query(intent)
            .filter { it.activityInfo.packageName != ctx.packageName }
            .map { ri ->
                AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name),
                    icon = IconShaper.shape(ri.loadIcon(pm), iconPx)
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}
