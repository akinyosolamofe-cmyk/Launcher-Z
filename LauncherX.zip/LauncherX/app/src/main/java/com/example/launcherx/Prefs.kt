package com.example.launcherx

import android.content.Context

/** Small SharedPreferences wrapper. Lists keep their order. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcherx", Context.MODE_PRIVATE)

    fun list(key: String): MutableList<String> =
        (sp.getString(key, "") ?: "").split("|").filter { it.isNotEmpty() }.toMutableList()

    fun setList(key: String, value: List<String>) {
        sp.edit().putString(key, value.joinToString("|")).apply()
    }

    fun str(key: String, def: String): String = sp.getString(key, def) ?: def

    fun setStr(key: String, value: String) {
        sp.edit().putString(key, value).apply()
    }

    fun remove(key: String) {
        sp.edit().remove(key).apply()
    }

    var cols: Int
        get() = sp.getInt("cols", 4)
        set(v) = sp.edit().putInt("cols", v).apply()

    var initialized: Boolean
        get() = sp.getBoolean("initialized", false)
        set(v) = sp.edit().putBoolean("initialized", v).apply()

    /** Index into Themes.all */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) = sp.edit().putInt("theme", v).apply()

    /** 0 = squircle (Xiaomi), 1 = circle, 2 = rounded square */
    var shape: Int
        get() = sp.getInt("shape", 0)
        set(v) = sp.edit().putInt("shape", v).apply()

    /** 0 = small, 1 = medium, 2 = large */
    var iconSize: Int
        get() = sp.getInt("iconSize", 1)
        set(v) = sp.edit().putInt("iconSize", v).apply()

    var labels: Boolean
        get() = sp.getBoolean("labels", true)
        set(v) = sp.edit().putBoolean("labels", v).apply()

    var clock: Boolean
        get() = sp.getBoolean("clock", true)
        set(v) = sp.edit().putBoolean("clock", v).apply()

    /** Package name of the chosen icon pack, empty = none */
    var iconPack: String
        get() = str("iconpack", "")
        set(v) = setStr("iconpack", v)
}
