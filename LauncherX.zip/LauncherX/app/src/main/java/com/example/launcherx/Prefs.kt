package com.example.launcherx

import android.content.Context

/** Small SharedPreferences wrapper. Lists keep their order. */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcherx", Context.MODE_PRIVATE)

    fun list(key: String): MutableList<String> =
        (sp.getString(key, "") ?: "").split("|").filter { it.isNotEmpty() }.toMutableList()

    fun setList(key: String, value: List<String>) {
        sp.edit().putString(key, value.joinToString("|")).apply()
    }

    var cols: Int
        get() = sp.getInt("cols", 4)
        set(v) = sp.edit().putInt("cols", v).apply()

    var initialized: Boolean
        get() = sp.getBoolean("initialized", false)
        set(v) = sp.edit().putBoolean("initialized", v).apply()
}
