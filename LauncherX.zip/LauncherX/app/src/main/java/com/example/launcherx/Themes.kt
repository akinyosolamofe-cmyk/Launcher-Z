package com.example.launcherx

import android.graphics.Color

/** Colours used by the dock, drawer, search box, edge panel and folders. */
class Style(
    val name: String,
    val accent: Int,
    val dock: Int,
    val drawer: Int,
    val search: Int,
    val edge: Int,
    val folder: Int,
    val drawerText: Int,
    val drawerHint: Int
)

object Themes {
    private fun c(s: String): Int = Color.parseColor(s)

    val all: List<Style> = listOf(
        Style(
            "HyperOS Orange", c("#FF6700"), c("#40FFFFFF"), c("#EB121216"),
            c("#26FFFFFF"), c("#E61C1C22"), c("#66FFFFFF"), Color.WHITE, c("#99FFFFFF")
        ),
        Style(
            "Ocean Blue", c("#3D8BFF"), c("#403D8BFF"), c("#F0101826"),
            c("#263D8BFF"), c("#E6101826"), c("#663D8BFF"), Color.WHITE, c("#99FFFFFF")
        ),
        Style(
            "Rose Pink", c("#FF4F81"), c("#40FF4F81"), c("#F0221018"),
            c("#26FF4F81"), c("#E6221018"), c("#66FF4F81"), Color.WHITE, c("#99FFFFFF")
        ),
        Style(
            "Forest Green", c("#2ECC71"), c("#402ECC71"), c("#F00F1C14"),
            c("#262ECC71"), c("#E60F1C14"), c("#662ECC71"), Color.WHITE, c("#99FFFFFF")
        ),
        Style(
            "Light", c("#FF6700"), c("#99FFFFFF"), c("#F2F5F5F7"),
            c("#14000000"), c("#F2FFFFFF"), c("#99FFFFFF"), c("#1B1B1F"), c("#77000000")
        )
    )

    fun get(index: Int): Style = all[index.coerceIn(0, all.size - 1)]
}
