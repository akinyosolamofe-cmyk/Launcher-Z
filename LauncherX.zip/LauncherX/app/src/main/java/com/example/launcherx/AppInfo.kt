package com.example.launcherx

import android.content.ComponentName
import android.graphics.Bitmap

/**
 * One tile on the home screen / drawer. A folder is also an AppInfo (folderId != null)
 * so the same adapter can draw both.
 */
data class AppInfo(
    val label: String,
    val component: ComponentName,
    val icon: Bitmap,
    val folderId: String? = null
) {
    val key: String = if (folderId != null) "folder:$folderId" else component.flattenToString()
}
