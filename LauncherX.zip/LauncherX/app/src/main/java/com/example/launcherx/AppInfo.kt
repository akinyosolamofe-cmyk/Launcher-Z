package com.example.launcherx

import android.content.ComponentName
import android.graphics.Bitmap

data class AppInfo(
    val label: String,
    val component: ComponentName,
    val icon: Bitmap
) {
    val key: String = component.flattenToString()
}
