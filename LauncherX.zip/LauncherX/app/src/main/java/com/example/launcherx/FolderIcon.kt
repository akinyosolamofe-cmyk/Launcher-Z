package com.example.launcherx

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF

/** Draws a HyperOS-style folder icon: a translucent rounded square with a 3x3 preview of its apps. */
object FolderIcon {

    fun make(icons: List<Bitmap>, size: Int, bg: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        bgPaint.color = bg
        c.drawRoundRect(RectF(0f, 0f, s, s), s * 0.28f, s * 0.28f, bgPaint)

        val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val pad = s * 0.12f
        val gap = s * 0.04f
        val cell = (s - 2f * pad - 2f * gap) / 3f

        icons.take(9).forEachIndexed { i, b ->
            val col = i % 3
            val row = i / 3
            val l = pad + col * (cell + gap)
            val t = pad + row * (cell + gap)
            c.drawBitmap(b, null, RectF(l, t, l + cell, t + cell), iconPaint)
        }
        return bmp
    }
}
