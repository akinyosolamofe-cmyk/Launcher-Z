package com.example.launcherx

import android.content.ComponentName
import android.content.Context
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.util.Xml
import org.xmlpull.v1.XmlPullParser

/**
 * Reads a standard (ADW / Nova / Apex style) icon pack. Packs list their icons in appfilter.xml:
 *   <item component="ComponentInfo{pkg/activity}" drawable="name" />
 */
class IconPack(ctx: Context, private val pkg: String) {

    private val res: Resources = ctx.packageManager.getResourcesForApplication(pkg)
    private val map = HashMap<String, String>()

    init {
        try {
            parse()
        } catch (e: Exception) {
            // a broken pack simply gives no icons
        }
    }

    private fun parse() {
        var parser: XmlPullParser? = null
        val id = res.getIdentifier("appfilter", "xml", pkg)
        if (id != 0) {
            parser = res.getXml(id)
        } else {
            try {
                val input = res.assets.open("appfilter.xml")
                val p = Xml.newPullParser()
                p.setInput(input, "utf-8")
                parser = p
            } catch (e: Exception) {
                parser = null
            }
        }
        if (parser == null) return

        var event = parser.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && parser.name == "item") {
                val comp = parser.getAttributeValue(null, "component")
                val drawable = parser.getAttributeValue(null, "drawable")
                if (comp != null && drawable != null) {
                    val s = comp.substringAfter("ComponentInfo{", "").substringBefore("}")
                    if (s.isNotEmpty()) map[s] = drawable
                }
            }
            event = parser.next()
        }
    }

    fun drawableFor(c: ComponentName): Drawable? {
        val name = map[c.packageName + "/" + c.className] ?: return null
        val id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) return null
        return try {
            res.getDrawable(id, null)
        } catch (e: Exception) {
            null
        }
    }
}
