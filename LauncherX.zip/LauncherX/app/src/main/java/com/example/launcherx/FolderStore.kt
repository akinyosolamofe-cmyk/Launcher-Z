package com.example.launcherx

/**
 * Folders live in Prefs:
 *   "folders"      -> list of folder ids
 *   "fname_<id>"   -> folder name
 *   "fapps_<id>"   -> ordered list of app keys inside the folder
 * The home screen refers to a folder with the key "folder:<id>".
 */
class FolderStore(private val prefs: Prefs) {

    fun ids(): MutableList<String> = prefs.list("folders")

    fun name(id: String): String = prefs.str("fname_$id", "Folder")

    fun setName(id: String, name: String) {
        prefs.setStr("fname_$id", name)
    }

    fun apps(id: String): MutableList<String> = prefs.list("fapps_$id")

    fun setApps(id: String, list: List<String>) {
        prefs.setList("fapps_$id", list)
    }

    fun create(name: String): String {
        val id = System.currentTimeMillis().toString(36)
        val all = ids()
        all.add(id)
        prefs.setList("folders", all)
        setName(id, name)
        setApps(id, emptyList())
        return id
    }

    fun delete(id: String) {
        val all = ids()
        all.remove(id)
        prefs.setList("folders", all)
        prefs.remove("fname_$id")
        prefs.remove("fapps_$id")
    }

    fun folderOf(key: String): String? = ids().firstOrNull { key in apps(it) }
}
