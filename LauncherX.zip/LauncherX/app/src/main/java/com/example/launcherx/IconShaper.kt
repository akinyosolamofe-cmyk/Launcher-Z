package com.example.launcherx

import android.graphics.AdaptiveIconDrawable
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.Drawable

/**
 * Xiaomi/HyperOS style: every icon is forced into the same rounded squircle,
 * and rendered once into a small bitmap (cheap to draw on low-end phones).
 */
object IconShaper {

    fun shape(d: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()

        if (d is AdaptiveIconDrawable) {
            // Adaptive layers are 108dp with the 72dp centre visible -> scale so the visible part fills the icon
            val off = (size * 0.25f).toInt()
            d.background?.let {
                it.setBounds(-off, -off, size + off, size + off)
                it.draw(c)
            }
            d.foreground?.let {
                it.setBounds(-off, -off, size + off, size + off)
                it.draw(c)
            }
        } else {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
            c.drawRect(0f, 0f, s, s, bg)
            val inset = (size * 0.16f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(c)
        }

        // Cut the squircle mask out of the result
        val mask = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        val r = s * 0.28f
        c.drawRoundRect(RectF(0f, 0f, s, s), r, r, mask)
        return bmp
    }
}
