package com.example.launcherx

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable

/**
 * Every icon is forced into the same shape and rendered once into a small bitmap
 * (cheap to draw on low-end phones).
 */
object IconShaper {

    /** Corner radius as a fraction of the icon size for each shape setting. */
    fun radiusFor(shape: Int): Float = when (shape) {
        1 -> 0.5f   // circle
        2 -> 0.16f  // rounded square
        else -> 0.28f // squircle (Xiaomi style)
    }

    fun shape(d: Drawable, size: Int, radius: Float): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()

        if (d is AdaptiveIconDrawable) {
            // Adaptive layers are 108dp with the 72dp centre visible -> scale so the visible part fills the icon
            val off = (size * 0.25f).toInt()
            d.background?.let {
                it.setBounds(-off, -off, size + off, size + off)
                it.draw(c)
            }
            d.foreground?.let {
                it.setBounds(-off, -off, size + off, size + off)
                it.draw(c)
            }
        } else {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.color = Color.WHITE
            c.drawRect(0f, 0f, s, s, bg)
            val inset = (size * 0.16f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
            d.draw(c)
        }

        // Cut the shape mask out of the result
        val mask = Paint(Paint.ANTI_ALIAS_FLAG)
        mask.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        val r = s * radius
        c.drawRoundRect(RectF(0f, 0f, s, s), r, r, mask)
        return bmp
    }

    /** Icon-pack icons already have their own shape, so they are drawn as they are. */
    fun raw(d: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return bmp
    }
}
