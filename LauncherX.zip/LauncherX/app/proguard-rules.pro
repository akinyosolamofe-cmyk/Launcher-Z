# LauncherX needs no special keep rules.
